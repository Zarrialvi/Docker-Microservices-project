INSERT INTO users (username, firstname, lastname, role) VALUES
  ('admin', 'Foo', 'Bar', 1),
  ('johnd', 'John', 'Doe', 0),
  ('janed', 'Jane', 'Doe', 0);